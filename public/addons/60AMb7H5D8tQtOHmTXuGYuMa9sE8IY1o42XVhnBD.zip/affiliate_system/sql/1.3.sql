CREATE TABLE `affiliate_withdraw_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` double(10,2) NOT NULL,
  `status` int(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `affiliate_withdraw_requests`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `affiliate_withdraw_requests`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

COMMIT;
